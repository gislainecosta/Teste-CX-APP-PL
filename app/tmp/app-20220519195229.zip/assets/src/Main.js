import Core from "./Core.js";

const client = ZAFClient.init();
let settings;

client.metadata().then((metadata) => {
  settings = metadata.settings;
});

const Main = async () => {
  const App = document.getElementById("app");
  let appBody = `
  <div id="main-content">
    <h2>Insira o CEP</h2>
    <input type="text" id="cep" name="cep" placeholder="CEP" maxlength="8" />
  
  
  </div>`;

  App.innerHTML = appBody;
};

export default Main;
