const aNewFunction = () => {
  console.log('ESTÁ CHAMANDO ESTA FUNÇÃO')
};

const Core = {
  aNewFunction,
};

export default Core;
