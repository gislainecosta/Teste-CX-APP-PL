client = window.ZAFClient.init()

const searchCEP = () => {

  client.get('ticket').then(function (data) {
    console.log(data);
  });


  const cep = document.querySelector("#input-cep").value
  client.get(`https://viacep.com.br/ws/${cep}/json/`)
    .then(function (data) {
      console.log(data);
    })
    .catch(function (e) {
      console.log(`Error request ${e}`);
    });

};

const Core = {
  searchCEP
};

export default Core;
